﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace WebApplication2
{
    public partial class lOGIN : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTN1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TrainingDatabaseConnectionString"].ToString());
                SqlCommand cmd = new SqlCommand("select * from registration where userId=@username and password=@word", con);
                cmd.Parameters.AddWithValue("@username", TXT1.Text);
                cmd.Parameters.AddWithValue("@word", TXT2.Text);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
               
                if (dt.Rows.Count > 0){
                    foreach (DataRow dr in dt.Rows)
                    {
                        char x = Convert.ToChar(dr["usertype"]);
                        if (x == 'A' || x == 'a')
                        {
                            Session.Add("user", TXT1.Text);
                            Response.Redirect("Admin.aspx");
                        }
                        else if (x == 'U' || x == 'u')
                        {
                            Session.Add("user", TXT1.Text);
                            Response.Redirect("user.aspx");
                        }
                        else {
                           
                        }


                    }


                
                }
                else
                {
                    
                    //Response.Redirect("lOGIN.aspx");
    Page.ClientScript.RegisterStartupScript(Page.GetType(), "scripts", "<Script>alert('Invalid userId and password');</script>");

                    TXT1.Text = "";
                    TXT2.Text = "";
                   

                }  
  
 } 
            catch{
              //  System.Windows.Forms.MessageBox.Show(ex.Message); 
            }
           

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
        
    }
}