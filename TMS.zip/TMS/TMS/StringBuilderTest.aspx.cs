﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication2
{
    public partial class StringBuilderTest : System.Web.UI.Page
    {   int score=0;
   
    
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
      
        protected void Button1_Click(object sender, EventArgs e)
        { 
           // string y=RadioButtonList1.
            string str=(RadioButtonList1.SelectedItem.ToString());
            string str1 = (RadioButtonList2.SelectedItem.ToString());
          //  Response.Write(str);
            if (str == "a sequence of characters" && str1 == "Trim()")
            {
                score = 20;
                System.Windows.Forms.MessageBox.Show("Correct"+score);
            }

           
            else if (str1 == "Trim()"&& str != "a sequence of characters"||str1 != "Trim()" && str == "a sequence of characters")
            {
                score = 10;
                System.Windows.Forms.MessageBox.Show("Only one is Correct"+score);
            }
            else 
            {
                score = 0;
                System.Windows.Forms.MessageBox.Show("InCorrect" + score);
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        { try

            {



                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TrainingDatabaseConnectionString1"].ToString());

                string insert = "insert into score values(@userId,@courseCode,@completionDate,@score)";

                SqlCommand cmd = new SqlCommand(insert, con);



                cmd.Parameters.AddWithValue("@userId", Session["user"].ToString());

                cmd.Parameters.AddWithValue("@courseCode", Session["t"].ToString());

                DateTime d = DateTime.Now;

                cmd.Parameters.AddWithValue("@completionDate",d.ToShortDateString());

                cmd.Parameters.AddWithValue("@score", score);

                con.Open();

                int a = cmd.ExecuteNonQuery();

                if (a != 0)

                {

                    Response.Write("Record inserted in db");

                    //  Response.Redirect("lOGIN.aspx");

                }

            }

            catch { }

         //  Response.Redirect("StringBuilderReport.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("StringBuilderReport.aspx");
        } 
        
        }



      
    
}