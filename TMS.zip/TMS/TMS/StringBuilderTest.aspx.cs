﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class StringBuilderTest : System.Web.UI.Page
    {   int score=0;
    
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        { 
           // string y=RadioButtonList1.
            string str=(RadioButtonList1.SelectedItem.ToString());
            string str1 = (RadioButtonList2.SelectedItem.ToString());
          //  Response.Write(str);
            if (str == "a sequence of characters" && str1 == "Trim()")
            {
                score = 20;
                System.Windows.Forms.MessageBox.Show("Correct"+score);
            }

           
            else if (str1 == "Trim()"&& str != "a sequence of characters"||str1 != "Trim()" && str == "a sequence of characters")
            {
                score = 10;
                System.Windows.Forms.MessageBox.Show("Only one is Correct"+score);
            }
            else 
            {
                score = 0;
                System.Windows.Forms.MessageBox.Show("InCorrect" + score);
            }

        }

      
    }
}