﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

using System.Configuration;

namespace WebApplication2
{
    public partial class course1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["db1ConnectionString3"].ToString());
                string query = "select * from course where courseDescription LIKE '" + TextBox1.Text + "'";
                //  SqlCommand com = new SqlCommand(query, con);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                da.Fill(ds, "course");
                GridView1.DataSourceID = null;



                GridView1.DataSource = ds.Tables["course"];

                SqlCommandBuilder comd = new SqlCommandBuilder(da);
                da.Update(ds, "course");
                ds.Tables[0].AcceptChanges();
            }
            catch { }

        }
    }
}