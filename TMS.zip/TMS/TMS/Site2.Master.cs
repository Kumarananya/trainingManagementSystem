﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace WebApplication2
{
    public partial class Site2 : System.Web.UI.MasterPage
    {
        public SqlConnection con;
        public string constr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //private void rep_bind()
        //{
        //    //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["db1ConnectionString"].ToString());
        //    //string query = "select courseDescription,skillSet  from course where (courseDescription like'" + TextBox1.Text + "%' OR  skillSet ='" + TextBox1.Text + "%')";

        //    //SqlDataAdapter da = new SqlDataAdapter(query, con);
        //    //DataSet ds = new DataSet();
        //    //da.Fill(ds);
        //   // GridView1.DataSourceID = null;
        //    //GridView1.DataSource = ds;
        //    //GridView1.DataBind();


        //}


        protected void Button1_Click(object sender, EventArgs e)
        {
            

            /*    con.Open();
                SqlDataReader dr;
                dr = com.ExecuteReader();


                if (dr.HasRows)
                {
                    dr.Read();
                    DataTable dt = new DataTable();
                    dt.Load(dr);
                   // GridView1.Visible = true;
                    GridView1.DataSourceID = null;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
              
                  //  GridView1.Visible = true;

                    TextBox1.Text = "";
                   // Label1.Text = "";
                }
                else
                {
                    GridView1.Visible = false;
                   // Label1.Visible = true;
                    Response.Write( "The search Term " + TextBox1.Text + " &nbsp;Is Not Available in the Records") ;

                }
             }*/

        }

        

    }
    }
